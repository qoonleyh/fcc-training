A Pen created at CodePen.io. You can find this one at https://codepen.io/qoonleyh/pen/LgaEXY.

 I am doing my first challenge on free code camp
